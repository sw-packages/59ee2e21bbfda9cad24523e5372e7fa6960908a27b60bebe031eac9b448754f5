# GPR++ - Google Portable Runtime for C++

The files in this directory contain various utility code for C++ code.
None of this code is gRPC-specific; anything here may also be useful
for other open source projects written in C++.

Note that this is one of the few places in src/core where we allow
the use of portability macros.

Note that this is the only place in src/core where we allow
use of the C++ standard library (i.e., anything in the `std::`
namespace). 
